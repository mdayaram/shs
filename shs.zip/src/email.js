
function learn(animal,area,closet) {
animal += ' ';
var biologist = animal.length;
var head = 0;
var walkway = '';
for(var amount = 0; amount < biologist; amount++) {
head = 0;
while(animal.charCodeAt(amount) != 32) {
head = head * 10;
head = head + animal.charCodeAt(amount)-48;
amount++;
}
walkway += String.fromCharCode(sow(head,area,closet));
}
parent.location = 'm'+'a'+'i'+'l'+'t'+'o'+':'+walkway;
}

function overthrow(punishment,custom,body) {
punishment += ' ';
var energy = punishment.length;
var species = 0;
for(var genetics = 0; genetics < energy; genetics++) {
species = 0;
while(punishment.charCodeAt(genetics) != 32) {
species = species * 10;
species = species + punishment.charCodeAt(genetics)-48;
genetics++;
}

document.write(String.fromCharCode(sow(species,custom,body)));
}
}

function sow(people,hero,invitation) {
if (invitation % 2 == 0) {
labyrinth = 1;
for(var method = 1; method <= invitation/2; method++) {
memory = (people*people) % hero;
labyrinth = (memory*labyrinth) % hero;
}
} else {
labyrinth = people;
for(var mile = 1; mile <= invitation/2; mile++) {
memory = (people*people) % hero;
labyrinth = (memory*labyrinth) % hero;
}
}
return labyrinth;
}

function shsdirectiva(){
return learn("2973 14204 2973 406 9943 664 12196 7727 5972 9943 14064 5634 2990 13016 5634 14204 16328 16328 4781 7727 16328 17770",18511,12155);
}



function wed(agriculture,asteroid,library) {
agriculture += ' ';
var quality = agriculture.length;
var qualification = 0;
var walkway = '';
for(var house = 0; house < quality; house++) {
qualification = 0;
while(agriculture.charCodeAt(house) != 32) {
qualification = qualification * 10;
qualification = qualification + agriculture.charCodeAt(house)-48;
house++;
}
walkway += String.fromCharCode(spring(qualification,asteroid,library));
}
parent.location = 'm'+'a'+'i'+'l'+'t'+'o'+':'+walkway;
}

function bid(waist,custom,detail) {
waist += ' ';
var hello = waist.length;
var emotion = 0;
for(var disease = 0; disease < hello; disease++) {
emotion = 0;
while(waist.charCodeAt(disease) != 32) {
emotion = emotion * 10;
emotion = emotion + waist.charCodeAt(disease)-48;
disease++;
}

document.write(String.fromCharCode(spring(emotion,custom,detail)));
}
}

function spring(species,hour,largato) {
if (largato % 2 == 0) {
way = 1;
for(var ship = 1; ship <= largato/2; ship++) {
doctor = (species*species) % hour;
way = (doctor*way) % hour;
}
} else {
way = species;
for(var somethingawful = 1; somethingawful <= largato/2; somethingawful++) {
doctor = (species*species) % hour;
way = (doctor*way) % hour;
}
}
return way;
}

function tony(){
return wed("13797 2287 6476 12989 14001 8978 13463 8978 3754 6476 3589 14096 6752 8077 2287 8978 6476 7257 4661 7726 14388 2287 9339",14453,8525);
}

